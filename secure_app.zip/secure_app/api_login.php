<?php
header('Content-Type: application/json');
require_once 'config.php';
require_once 'cors.php';

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!empty($email) && !empty($password)) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                if ($user['bloqueado_hasta'] && strtotime($user['bloqueado_hasta']) > time()) {
                    $response['message'] = "Usuario bloqueado hasta: " . $user['bloqueado_hasta'];
                } else {
                    if (password_verify($password, $user['password'])) {
                        $pdo->prepare("UPDATE usuarios SET intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id = ?")
                            ->execute([$user['id']]);

                        $pdo->prepare("DELETE FROM tokens WHERE usuario_id = ?")->execute([$user['id']]);

                        $token = bin2hex(random_bytes(16));
                        $expira = date('Y-m-d H:i:s', strtotime('+5 minutes'));

                        $stmtToken = $pdo->prepare("INSERT INTO tokens (usuario_id, token, expiracion) VALUES (?, ?, ?)");
                        $stmtToken->execute([$user['id'], $token, $expira]);

                        $response = [
                            'success' => true,
                            'message' => 'Login correcto',
                            'user' => [
                                'id' => $user['id'],
                                'email' => $user['email'],
                                'usuario' => $user['usuario']
                            ],
                            'token' => $token,
                            'expira' => $expira
                        ];
                    } else {
                        $intentos = $user['intentos_fallidos'] + 1;
                        $bloqueo = $intentos >= 3 ? date('Y-m-d H:i:s', strtotime('+3 minutes')) : null;

                        $pdo->prepare("UPDATE usuarios SET intentos_fallidos = ?, bloqueado_hasta = ? WHERE id = ?")
                            ->execute([$intentos, $bloqueo, $user['id']]);

                        $response['message'] = $intentos >= 3
                            ? "Usuario bloqueado por 3 minutos."
                            : "Contraseña incorrecta.";
                    }
                }
            } else {
                $response['message'] = "Usuario no encontrado.";
            }
        } catch (PDOException $e) {
            $response['message'] = "Error en la base de datos: " . $e->getMessage();
        }
    } else {
        $response['message'] = "Por favor, completa todos los campos.";
    }
} else {
    $response['message'] = "Método no permitido.";
}

echo json_encode($response);
?>
